package dados;

public class ItemChar {
    private char chave;

    public ItemChar(char elem){
        this.chave = elem;
    }

    public char getChave() {
        return chave;
    }

    public void setChave(char chave) {
        this.chave = chave;
    }

    
}
